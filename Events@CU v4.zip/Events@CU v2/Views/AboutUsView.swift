//
//  DonationsView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/12/24.
//

import SwiftUI

struct AboutUsView: View {
    var body: some View {
        Text("Donations")
            .font(.largeTitle)
            .bold()
    }
}

#Preview {
    ContentView()
}
