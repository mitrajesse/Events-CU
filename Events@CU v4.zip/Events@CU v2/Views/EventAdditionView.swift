//
//  EventAdditionView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/12/24.
//

import SwiftUI

struct EventAdditionView: View {
    var body: some View {
        Text("Add an Event")
            .font(.largeTitle)
            .bold()
    }
}

#Preview {
    ContentView()
}
