//
//  Event.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/12/24.
//

import SwiftUI

struct Event: Identifiable {
    let id = UUID()
    let date: String
    let name: String
    let location: String // Added location field
    let interestedPeople: Int
    let rsvpStatus: String
    
    static let sampleData: [Event] = [
        Event(date: "Sept 15, 2024", name: "Music Festival", location: "Auditorium", interestedPeople: 50, rsvpStatus: "RSVP'd"),
        Event(date: "Sept 20, 2024", name: "Tech Talk", location: "Main Hall", interestedPeople: 120, rsvpStatus: "Not RSVPd"),
        Event(date: "Sept 25, 2024", name: "Career Fair", location: "Conference Center", interestedPeople: 200, rsvpStatus: "RSVP'd"),
        Event(date: "Oct 1, 2024", name: "Art Exhibition", location: "Gallery", interestedPeople: 80, rsvpStatus: "RSVP'd"),
        Event(date: "Oct 5, 2024", name: "Startup Pitch", location: "Startup Hub", interestedPeople: 150, rsvpStatus: "Not RSVPd"),
        Event(date: "Oct 10, 2024", name: "Networking Event", location: "Banquet Hall", interestedPeople: 90, rsvpStatus: "RSVP'd"),
        Event(date: "Oct 15, 2024", name: "Hackathon", location: "Tech Lab", interestedPeople: 180, rsvpStatus: "Not RSVPd"),
        Event(date: "Oct 20, 2024", name: "Cooking Class", location: "Kitchen Studio", interestedPeople: 60, rsvpStatus: "RSVP'd")
    ]
    
    static let offCampusSampleData: [Event] = [
        Event(date: "Sept 10, 2024", name: "Mountain Hike", location: "Mountain Base", interestedPeople: 40, rsvpStatus: "RSVP'd"),
        Event(date: "Sept 17, 2024", name: "Beach Cleanup", location: "Sandy Beach", interestedPeople: 75, rsvpStatus: "RSVP'd"),
        Event(date: "Sept 30, 2024", name: "City Concert", location: "Downtown Plaza", interestedPeople: 180, rsvpStatus: "RSVP'd"),
        Event(date: "Oct 5, 2024", name: "Local Art Show", location: "City Gallery", interestedPeople: 100, rsvpStatus: "Not RSVPd"),
        Event(date: "Oct 12, 2024", name: "Food Truck Festival", location: "Town Square", interestedPeople: 220, rsvpStatus: "RSVP'd"),
        Event(date: "Oct 20, 2024", name: "Rock Climbing Trip", location: "Cliffside Park", interestedPeople: 50, rsvpStatus: "Not RSVPd"),
        Event(date: "Oct 27, 2024", name: "Camping Retreat", location: "Forest Reserve", interestedPeople: 80, rsvpStatus: "RSVP'd"),
        Event(date: "Nov 5, 2024", name: "Local Brewery Tour", location: "City Brewery", interestedPeople: 150, rsvpStatus: "RSVP'd")
    ]
}
