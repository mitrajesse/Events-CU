//
//  EditOrRemoveEventView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/12/24.
//

import SwiftUI

struct MyEventsView: View {
    var body: some View {
        Text("Edit or Remove an Event")
            .font(.largeTitle)
            .bold()
            .navigationTitle("Edit or Remove an Event")
    }
}

#Preview {
    ContentView()
}
