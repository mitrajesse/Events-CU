//
//  ContactUsView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/12/24.
//

import SwiftUI

struct ContactUsView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Contact Us")
                .font(.largeTitle)
                .bold()
                .padding(.bottom, 20)
            
            Button(action: {
                let phone = "tel://1234567890"
                if let url = URL(string: phone), UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                }
            }) {
                HStack {
                    Image(systemName: "phone.fill")
                    Text("Contact Campus Security")
                        .bold()
                }
                .foregroundColor(.blue)
            }
            
            Button(action: {
                let email = "mailto:developer@example.com"
                if let url = URL(string: email), UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                }
            }) {
                HStack {
                    Image(systemName: "envelope.fill")
                    Text("Contact Developers")
                        .bold()
                }
                .foregroundColor(.blue)
            }
            
            Link(destination: URL(string: "https://forms.gle/example")!) {
                HStack {
                    Image(systemName: "square.and.pencil")
                    Text("Feedback Form")
                        .bold()
                }
                .foregroundColor(.blue)
            }
            
            Spacer()
        }
        .padding()
        .navigationTitle("Contact Us")
    }
}

#Preview {
    ContentView()
}
