//
//  RewardsView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/12/24.
//

import SwiftUI

struct RewardsView: View {
    var body: some View {
        Text("Rewards")
            .font(.largeTitle)
            .bold()
            .navigationTitle("Rewards")
    }
}

#Preview {
    ContentView()
}
