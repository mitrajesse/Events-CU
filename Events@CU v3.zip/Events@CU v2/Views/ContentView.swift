import SwiftUI

struct ContentView: View {
    // Constants for reused colors
    let barBackgroundColor = Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1)) // Hex color #fcb716
    let appBackgroundColor = Color(UIColor(red: 0/255, green: 56/255, blue: 101/255, alpha: 1)) // Hex color #003865
    
    // State variable to control the drawer menu visibility
    @State private var isDrawerOpen = false
    
    var body: some View {
        NavigationView {
            ZStack {
                appBackgroundColor.ignoresSafeArea() // Set background color to #003865
                
                VStack {
                    topBar() // Add the top bar at the top of the screen
                    
                    Spacer()
                    
                    // Welcome message with multi-line text structure
                    VStack(spacing: 10) {
                        Text("Welcome to")
                            .font(.system(size: 36))
                            .foregroundColor(.white)
                            .bold()
                        
                        Text("Events@CU")
                            .font(.system(size: 48))
                            .foregroundColor(.white)
                            .bold()
                        
                        Text("-----")
                            .font(.system(size: 36))
                            .foregroundColor(.white)
                            .bold()
                    }
                    
                    Spacer()
                }
            }
            .safeAreaInset(edge: .bottom) {
                bottomBar()
                    .frame(maxWidth: .infinity) // Make bottom bar stretch across the width
            }
            .navigationTitle("")
            .overlay(
                // Overlay the drawer menu on top of the main content
                DrawerMenu(isOpen: $isDrawerOpen, backgroundColor: appBackgroundColor, titleColor: barBackgroundColor)
            )
        }
    }
    
    // MARK: - Top Bar with Hamburger and Account Icons
    @ViewBuilder
    private func topBar() -> some View {
        ZStack {
            barBackgroundColor // Set background color to hex #fcb716
                .ignoresSafeArea(edges: .top)
                .frame(height: 60)
            
            HStack {
                // Hamburger Menu Icon
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.2)) { // Set shorter animation duration
                        isDrawerOpen.toggle() // Toggle the drawer menu visibility
                    }
                }) {
                    Image("hamburger")
                        .resizable()
                        .frame(width: 48, height: 48)
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                // Account Icon
                Button(action: {
                    // Handle account icon action
                }) {
                    Image(systemName: "person.crop.circle")
                        .resizable()
                        .frame(width: 36, height: 36)
                        .foregroundColor(.black)
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, -10)
        }
    }
    
    // MARK: - Bottom Bar with Larger Icons and Text
    @ViewBuilder
    private func bottomBar() -> some View {
        ZStack {
            barBackgroundColor // Set background color to hex #fcb716
                .ignoresSafeArea(edges: .bottom)
                .frame(height: 110)

            HStack {
                Spacer()
                
                // On Campus Events Button
                VStack(spacing: 5) {
                    NavigationLink(destination: EventListView()) {
                        Image("bwschool")
                            .resizable()
                            .frame(width: 60, height: 60)
                    }
                    Text("On Campus")
                        .foregroundColor(.black)
                        .font(.system(size: 20))
                        .bold()
                }
                .padding(.top, 20)
                
                Spacer(minLength: 90)
                
                // Off Campus Events Button
                VStack(spacing: -5) {
                    NavigationLink(destination: OffCampusEventListView()) {
                        Image("bwcar")
                            .resizable()
                            .frame(width: 60, height: 60)
                    }
                    Text("Off Campus")
                        .foregroundColor(.black)
                        .font(.system(size: 20))
                        .bold()
                }
                .padding(.top, 30)
                
                Spacer()
            }
            .padding(.horizontal, 30)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Drawer Menu View
struct DrawerMenu: View {
    @Binding var isOpen: Bool
    let backgroundColor: Color
    let titleColor: Color
    
    // Adjustable space height
    let spaceHeight: CGFloat = 100 // Adjust this value to control space between "More" and buttons
    
    var body: some View {
        ZStack(alignment: .leading) {
            if isOpen {
                // Semi-transparent background to dim the main content
                Color.black.opacity(0.15)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.easeInOut(duration: 0.2)) { // Set shorter animation duration for closing
                            isOpen.toggle()
                        }
                    }
                
                // Drawer menu content
                VStack(alignment: .leading) {
                    // "More" title at the top
                    Text("More")
                        .font(.system(size: 32))
                        .bold()
                        .foregroundColor(titleColor)
                        .padding(.top, 20)
                    
                    // Spacer with adjustable height between "More" and buttons
                    Spacer()
                        .frame(height: spaceHeight)
                    
                    // NavigationLinks to separate views
                    VStack(alignment: .leading, spacing: 30) {
                        NavigationLink(destination: EventAdditionView()) {
                            Text("Add an Event")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                        
                        NavigationLink(destination: MyEventsView()) {
                            Text("My Events")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                        
                        NavigationLink(destination: RewardsView()) {
                            Text("Rewards")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                        
                        NavigationLink(destination: SettingsView()) {
                            Text("Settings")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                        
                        NavigationLink(destination: ContactUsView()) {
                            Text("Contact Us")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                        
                        NavigationLink(destination: DonationsView()) {
                            Text("Donations")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                    }
                    
                    Spacer()
                }
                .frame(width: UIScreen.main.bounds.width / 2) // Set the drawer width to half the screen width
                .background(backgroundColor)
                .transition(.move(edge: .leading))
            }
        }
    }
}

#Preview {
    ContentView()
}
