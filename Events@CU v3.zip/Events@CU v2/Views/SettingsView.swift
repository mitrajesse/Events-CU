//
//  SettingsView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/12/24.
//

import SwiftUI

struct SettingsView: View {
    var body: some View {
        Text("Notification Settings")
            .font(.largeTitle)
            .bold()
            .navigationTitle("Settings")
    }
}

#Preview {
    ContentView()
}
