import SwiftUI
import FirebaseFirestore

struct EventAdditionView: View {
    @State private var name: String = ""
    @State private var description: String = ""
    @State private var location: String = ""
    @State private var date: Date = Date()
    @State private var isOffCampus: Bool = false
    @State private var organizer: String = "" // Organizer's ID or name
    @EnvironmentObject var userViewModel: UserViewModel // Assuming the organizer is the logged-in user
    @State private var errorMessage: String? = nil
    @State private var isSubmitting: Bool = false

    let db = Firestore.firestore()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Add New Event")
                .font(.largeTitle)
                .fontWeight(.bold)

            TextField("Event Name", text: $name)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            TextField("Event Description", text: $description)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            TextField("Event Location", text: $location)
                .textFieldStyle(RoundedBorderTextFieldStyle())

            DatePicker("Event Date", selection: $date, displayedComponents: .date)
                .datePickerStyle(GraphicalDatePickerStyle())

            Toggle("Off-Campus Event", isOn: $isOffCampus)

            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .font(.caption)
            }

            Button(action: {
                addEvent()
            }) {
                Text(isSubmitting ? "Submitting..." : "Add Event")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isSubmitting ? Color.gray : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .disabled(isSubmitting)

            Spacer()
        }
        .padding()
    }

    // MARK: - Add Event to Firestore
    private func addEvent() {
        guard !name.isEmpty, !description.isEmpty, !location.isEmpty else {
            errorMessage = "Please fill in all fields."
            return
        }
        let organizerName = userViewModel.currentUser?.name ?? "Unknown Organizer"
        // Create a new Event object
        let newEvent = Event(
            id: UUID().uuidString,
            name: name,
            description: description,
            location: location,
            date: date,
            isOffCampus: isOffCampus,
            rsvp: [],
            organizer: organizerName // Assume this is the organizer's ID
        )

        // Save to Firestore
        let db = Firestore.firestore()
        db.collection("Events").document(newEvent.id).setData(newEvent.toDictionary()) { error in
            if let error = error {
                self.errorMessage = "Failed to add event: \(error.localizedDescription)"
            } else {
                self.errorMessage = nil
                // Clear the form
                self.name = ""
                self.description = ""
                self.location = ""
                self.isOffCampus = false
                self.date = Date()
            }
        }
    }

    // MARK: - Clear Input Fields
    private func clearFields() {
        name = ""
        description = ""
        location = ""
        date = Date()
        isOffCampus = false
    }
}



