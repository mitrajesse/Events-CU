//
//  Events_CUApp.swift
//  Events@CU
//
//  Created by Jesse Mitra on 9/12/24.
//

import SwiftUI

@main
struct Events_CUApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
