//
//  EventDetailView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/11/24.
//

import SwiftUI
import FirebaseFirestore
import FirebaseAuth
import Firebase

struct EventDetailView: View {
    @State var event: Event
    @EnvironmentObject var userViewModel: UserViewModel // Bindable to an @Observable object

    @State private var isRSVPed: Bool = false
    @State private var errorMessage: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            // Event Name
            Text(event.name)
                .font(.largeTitle)
                .fontWeight(.bold)
                .lineLimit(2)
                .multilineTextAlignment(.leading)

            // Event Description
            Text(event.description)
                .font(.body)

            // Event Date
            HStack {
                Image(systemName: "calendar")
                Text("Date: \(formattedDate(event.date))")
            }
            .font(.subheadline)

            // Event Location
            HStack {
                Image(systemName: "map")
                Text("Location: \(event.location)")
            }
            .font(.subheadline)

            // Organizer
            HStack {
                Image(systemName: "person.circle")
                Text("Organizer: \(event.organizer)")
            }
            .font(.subheadline)

            // RSVP Button
            Button(action: toggleRSVP) {
                Text(isRSVPed ? "Cancel RSVP" : "RSVP Now")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isRSVPed ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .padding(.vertical)

            // Error Message
            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .font(.caption)
            }

            Spacer()
        }
        .padding()
        .onAppear {
            // Check if the user is already RSVP'd
            if let userId = userViewModel.currentUser?.id {
                isRSVPed = event.rsvp.contains(userId)
            }
        }
    }

    // MARK: - Helper Functions
    private func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    private func toggleRSVP() {
        guard let userId = userViewModel.currentUser?.id else {
            errorMessage = "You must be signed in to RSVP."
            return
        }

        errorMessage = nil

        // Toggle RSVP
        if isRSVPed {
            // Remove RSVP
            if let index = event.rsvp.firstIndex(of: userId) {
                event.rsvp.remove(at: index)
            }
        } else {
            // Add RSVP
            event.rsvp.append(userId)
        }

        // Update Firestore
        updateEventInFirestore()
        isRSVPed.toggle()
    }

    private func updateEventInFirestore() {
        let db = Firestore.firestore()
        db.collection("Events").document(event.id).setData(event.toDictionary(), merge: true) { error in
            if let error = error {
                errorMessage = "Failed to update RSVP: \(error.localizedDescription)"
            }
        }
    }
}

