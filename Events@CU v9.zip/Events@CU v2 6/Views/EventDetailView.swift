//
//  EventDetailView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/11/24.
//

import SwiftUI
import UIKit

// MARK: - Event Detail View
struct EventDetailView: View {
    let event: Event

    @State private var isRSVPd = false
    @State private var isInterested = false
    @State private var isShareSheetShowing = false

    let barBackgroundColor = Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1)) // Hex color #fcb716
    let appBackgroundColor = Color(UIColor(red: 0/255, green: 56/255, blue: 101/255, alpha: 1)) // Hex color #003865
    
    var body: some View {
        NavigationView {
            ZStack {
                // Set entire background to appBackgroundColor
                appBackgroundColor.ignoresSafeArea()
                
                VStack {
                    
                    // Centered Event Title, Date, Location, and Host with reduced spacing and white text
                    VStack(alignment: .center, spacing: 8) {
                        Text(event.name)
                            .font(.largeTitle)
                            .bold()
                            .foregroundColor(barBackgroundColor)
                        
                        Text("Date: \(event.date)")
                            .font(.title2)
                            .foregroundColor(barBackgroundColor)
                        
                        Text("Location: \(event.location)")
                            .font(.title2)
                            .foregroundColor(barBackgroundColor)
                        
                        // Hosted by text with the same styling as date and location
                        Text("Hosted By: \(event.host)")
                            .font(.title2)
                            .foregroundColor(barBackgroundColor)
                    }
                    .frame(maxWidth: .infinity) // Center align by taking full width
                    .multilineTextAlignment(.center) // Center the text within the VStack
                    .padding(.horizontal)
                    
                    // Event Description Box with Placeholder Text
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white.opacity(0.1))
                        .frame(maxWidth: .infinity)
                        .padding()
                        .overlay(
                            Text("Event details and description will be available soon. Stay tuned!")
                                .foregroundColor(.white)
                                .font(.body)
                                .padding()
                        )
                    
                    Spacer()
                    
                    // Centered HStack with icon-only buttons at the bottom of the screen
                    HStack(spacing: 40) {
                        Button(action: {
                            isRSVPd.toggle() // Toggle RSVP status
                        }) {
                            Image(systemName: isRSVPd ? "checkmark.circle.fill" : "checkmark.circle") // RSVP icon
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .foregroundColor(barBackgroundColor)
                        }
                        
                        Button(action: {
                            isInterested.toggle() // Toggle interest status
                        }) {
                            Image(systemName: isInterested ? "heart.fill" : "heart") // Interested icon
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .foregroundColor(barBackgroundColor)
                        }
                        
                        Button(action: {
                            isShareSheetShowing = true // Show the share sheet
                        }) {
                            Image(systemName: "square.and.arrow.up") // Share icon
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .foregroundColor(barBackgroundColor)
                        }
                        .sheet(isPresented: $isShareSheetShowing) {
                            ShareSheet(activityItems: ["Check out this event: \(event.name) on \(event.date) at \(event.location)"])
                                .presentationDetents([.medium, .large]) // Present at half screen by default
                        }
                    }
                    .frame(maxWidth: .infinity) // Center the HStack
                    .padding(.horizontal)
                    .padding(.bottom, 20)
                }
                .padding(.top)
            }
            // Remove navigation title line
        }
    }
}

// Share Sheet UIViewControllerRepresentable for SwiftUI
struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

#Preview {
    ContentView()
}
