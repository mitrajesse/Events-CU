//
//  UserViewModel.swift
//  Events@CU
//
//  Created by Aaron Summers on 11/15/24.
//


import Foundation
import FirebaseAuth
import FirebaseFirestore

class UserViewModel: ObservableObject {
    @Published var userName: String = "" // Default placeholder for the user's name
    @Published var isLoggedIn: Bool = Auth.auth().currentUser != nil // Tracks login state

    private let db = Firestore.firestore()

    // MARK: - Fetch User's Name
    func fetchUserName() {
        guard let user = Auth.auth().currentUser else {
            self.userName = ""
            return
        }

        let userDoc = db.collection("Users").document(user.uid)
        userDoc.getDocument { snapshot, error in
            if let snapshot = snapshot, snapshot.exists {
                self.userName = snapshot.data()?["name"] as? String ?? ""
            } else {
                self.userName = "" // Default value if no name is found
            }
        }
    }

    // MARK: - Save User's Name
    func saveUserName(_ name: String, completion: @escaping (Bool, String?) -> Void) {
        guard let user = Auth.auth().currentUser else {
            completion(false, "User not logged in.")
            return
        }

        let userDoc = db.collection("Users").document(user.uid)
        userDoc.setData(["name": name], merge: true) { error in
            if let error = error {
                completion(false, error.localizedDescription)
            } else {
                self.userName = name
                completion(true, nil)
            }
        }
    }

    // MARK: - Log In User
    func login(email: String, password: String, completion: @escaping (Bool, String?) -> Void) {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                completion(false, error.localizedDescription)
                return
            }

            self.isLoggedIn = true
            self.fetchUserName() // Fetch the name after login
            completion(true, nil)
        }
    }

    // MARK: - Create User Account
    func createAccount(email: String, password: String, name: String, completion: @escaping (Bool, String?) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                completion(false, error.localizedDescription)
                return
            }

            guard let user = result?.user else {
                completion(false, "Failed to create user.")
                return
            }

            // Save user details in Firestore
            let userData: [String: Any] = [
                "name": name,
                "email": email,
                "isAdmin": false,
                "createdAt": Timestamp(date: Date())
            ]

            self.db.collection("Users").document(user.uid).setData(userData) { error in
                if let error = error {
                    completion(false, error.localizedDescription)
                } else {
                    self.userName = name
                    self.isLoggedIn = true
                    completion(true, nil)
                }
            }
        }
    }

    // MARK: - Log Out User
    func logout(completion: @escaping (Bool, String?) -> Void) {
        do {
            try Auth.auth().signOut()
            self.isLoggedIn = false
            self.userName = ""
            completion(true, nil)
        } catch {
            completion(false, error.localizedDescription)
        }
    }
}
