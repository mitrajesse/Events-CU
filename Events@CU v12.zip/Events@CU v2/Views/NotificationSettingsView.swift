//
//  SettingsView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/12/24.
//

import SwiftUI

struct NotificationSettingsView: View {
    @State private var pushNotificationsEnabled = false
    @State private var emailNotificationsEnabled = false
    
    let appBackgroundColor = Color(UIColor(red: 0/255, green: 56/255, blue: 101/255, alpha: 1)) // Hex color #003865
    let barBackgroundColor = Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1)) // Hex color #fcb716
    
    var body: some View {
        ZStack {
            // Set the background color to match the other views
            appBackgroundColor.ignoresSafeArea()
            
            VStack(spacing: 20) {
                // Headline Text
                Text("Notification Settings")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(barBackgroundColor) // Match title color with other views
                    .padding(.bottom, 20)
                
                // VStack for concise notification options with toggles
                VStack(alignment: .leading, spacing: 15) {
                    // Push Notifications Toggle
                    HStack {
                        Text("Push Notifications")
                            .font(.title3)
                            .foregroundColor(.white)
                            .bold()
                        
                        Spacer()
                        
                        Toggle("", isOn: $pushNotificationsEnabled)
                            .labelsHidden()
                            .toggleStyle(SwitchToggleStyle(tint: barBackgroundColor))
                    }
                    
                    // Email Notifications Toggle
                    HStack {
                        Text("Email Notifications")
                            .font(.title3)
                            .foregroundColor(.white)
                            .bold()
                        
                        Spacer()
                        
                        Toggle("", isOn: $emailNotificationsEnabled)
                            .labelsHidden()
                            .toggleStyle(SwitchToggleStyle(tint: barBackgroundColor))
                    }
                }
                .padding(.horizontal)
                
                Spacer()
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
