//
//  AboutUsView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/12/24.
//

import SwiftUI

struct AboutUsView: View {
    let appBackgroundColor = Color(UIColor(red: 0/255, green: 56/255, blue: 101/255, alpha: 1)) // Hex color #003865
    let barBackgroundColor = Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1)) // Hex color #fcb716
    
    var body: some View {
        ZStack {
            // Set the entire background to appBackgroundColor
            appBackgroundColor.ignoresSafeArea()
            
            VStack(spacing: 20) {
                // Title with matching color from EventDetailView
                Text("About Us")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(barBackgroundColor)
                
                // Developers Section
                VStack(alignment: .leading, spacing: 10) {
                    Text("Developers")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.black)
                    
                    Text("Events@CU was developed by a passionate team of developers dedicated to bringing students closer to campus events. Our goal is to make it easier for everyone to stay informed and engaged with what’s happening at CU!")
                        .font(.body)
                        .foregroundColor(.black)
                }
                .padding()
                .background(barBackgroundColor) // Matching background color
                .cornerRadius(12)
                .padding(.horizontal)
                
                // Donations Section
                VStack(alignment: .leading, spacing: 10) {
                    Text("Support Us")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.black)
                    
                    Text("If you’d like to support the development of Events@CU, please consider making a donation. Every bit helps us improve the app and continue delivering valuable features for the community!")
                        .font(.body)
                        .foregroundColor(.black)
                    
                    // Donations Button
                    Button(action: openDonationLink) {
                        Text("Donate Now")
                            .bold()
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(appBackgroundColor) // Matching app background color
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding(.top)
                }
                .padding()
                .background(barBackgroundColor) // Matching rounded rectangle background color
                .cornerRadius(12)
                .padding(.horizontal)
                
                Spacer()
            }
            .padding()
        }
    }
    
    // Function to open the donations link
    private func openDonationLink() {
        if let url = URL(string: "https://www.youtube.com/") {
            UIApplication.shared.open(url)
        }
    }
}

#Preview {
    ContentView()
}
