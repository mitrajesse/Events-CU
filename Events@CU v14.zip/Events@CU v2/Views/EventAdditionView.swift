//
//  EventAdditionView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/12/24.
//

import SwiftUI
import FirebaseFirestore

struct EventAdditionView: View {
    @State private var name: String = ""
    @State private var description: String = ""
    @State private var date = Date()
    @State private var location: String = ""
    @State private var isOffCampus = false
    @State private var filteredEventLocations: [String] = []
    @State private var showSuggestions = false
    @State private var showAlert = false
    @State private var alertMessage = ""

    // Firebase Firestore reference
    private let db = Firestore.firestore()

    // Separate lists for on-campus and off-campus locations
    let onCampusLocations = [
        "Auditorium", "Main Hall", "Conference Center", "Gallery",
        "Startup Hub", "Banquet Hall", "Tech Lab", "Kitchen Studio"
    ]
    
    let offCampusLocations = [
        "Mountain Base", "Sandy Beach", "Downtown Plaza", "City Gallery",
        "Town Square", "Cliffside Park", "Forest Reserve", "City Brewery"
    ]
    
    let barBackgroundColor = Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1))
    let appBackgroundColor = Color(UIColor(red: 0/255, green: 56/255, blue: 101/255, alpha: 1))

    var body: some View {
        NavigationView {
            ZStack {
                appBackgroundColor.ignoresSafeArea()
                
                VStack(spacing: 20) {
                    Text("Create New Event")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.white)
                    
                    // Event Name
                    TextField("Event Name", text: $name)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(8)
                    
                    // Description
                    VStack(alignment: .leading) {
                        Text("Description")
                            .foregroundColor(.white)
                        TextEditor(text: $description)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(8)
                            .frame(height: 150)
                    }
                    
                    // Date Picker
                    DatePicker("Date", selection: $date, displayedComponents: .date)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(8)
                    
                    // On/Off-Campus Toggle
                    Toggle("Is this event off-campus?", isOn: $isOffCampus)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(8)
                        .onChange(of: isOffCampus) {
                            filterEventLocations(query: location)
                        }
                    
                    // Location with Suggestions
                    VStack {
                        TextField("Location", text: $location, onEditingChanged: { _ in
                            self.showSuggestions = true
                        })
                        .onChange(of: location) {
                            filterEventLocations(query: location)
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(8)
                        
                        if showSuggestions && !filteredEventLocations.isEmpty {
                            ScrollView {
                                VStack(alignment: .leading) {
                                    ForEach(filteredEventLocations, id: \.self) { suggestion in
                                        Text(suggestion)
                                            .padding(.vertical, 8)
                                            .padding(.horizontal)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .background(Color.white)
                                            .onTapGesture {
                                                location = suggestion
                                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                                    showSuggestions = false
                                                }
                                            }
                                    }
                                }
                            }
                            .frame(height: 150)
                            .background(Color.white)
                            .cornerRadius(8)
                        }
                    }
                    
                    // Create Event Button
                    Button(action: createEvent) {
                        Text("Create Event")
                            .bold()
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(barBackgroundColor)
                            .cornerRadius(8)
                    }
                }
                .padding()
                .alert(isPresented: $showAlert) {
                    Alert(title: Text("Event Creation"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
                }
            }
        }
    }
    
    // Function to filter locations based on input and campus selection
    private func filterEventLocations(query: String) {
        let locations = isOffCampus ? offCampusLocations : onCampusLocations
        if query.isEmpty {
            filteredEventLocations = []
            showSuggestions = false
        } else {
            filteredEventLocations = locations.filter { $0.lowercased().contains(query.lowercased()) }
            showSuggestions = true
        }
    }
    
    // Function to create an event in Firebase Firestore
    private func createEvent() {
        guard !name.isEmpty, !description.isEmpty, !location.isEmpty else {
            alertMessage = "Please fill in all fields."
            showAlert = true
            return
        }

        // Create event data
        let eventData: [String: Any] = [
            "name": name,
            "description": description,
            "date": Timestamp(date: date),
            "location": location,
            "isOffCampus": isOffCampus
        ]

        // Save event to Firestore
        db.collection("Events").addDocument(data: eventData) { error in
            if let error = error {
                alertMessage = "Failed to create event: \(error.localizedDescription)"
            } else {
                alertMessage = "Event created successfully!"
                resetFields()
            }
            showAlert = true
        }
    }

    // Function to reset input fields after event creation
    private func resetFields() {
        name = ""
        description = ""
        date = Date()
        location = ""
        isOffCampus = false
        showSuggestions = false
        filteredEventLocations = []
    }
}

// Preview
#Preview {
    EventAdditionView()
}
