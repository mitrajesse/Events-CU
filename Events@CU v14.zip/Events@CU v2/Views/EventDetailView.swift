//
//  EventDetailView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/11/24.
//

import SwiftUI

struct EventDetailView: View {
    let event: Event

    @State private var isRSVPd = false
    @State private var isInterested = false
    @State private var isShareSheetShowing = false

    let barBackgroundColor = Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1)) // Hex color #fcb716
    let appBackgroundColor = Color(UIColor(red: 0/255, green: 56/255, blue: 101/255, alpha: 1)) // Hex color #003865

    var body: some View {
        ZStack {
            appBackgroundColor.ignoresSafeArea()

            VStack {
                // Centered Event Title, Date, Location, and Host
                VStack(alignment: .center, spacing: 8) {
                    Text(event.name)
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(barBackgroundColor)

                    Text("Date: \(event.date)")
                        .font(.title2)
                        .foregroundColor(barBackgroundColor)

                    Text("Location: \(event.location)")
                        .font(.title2)
                        .foregroundColor(barBackgroundColor)

                    Text("Hosted By: \(event.host)")
                        .font(.title2)
                        .foregroundColor(barBackgroundColor) // Host styled in gold/yellow
                }
                .multilineTextAlignment(.center)
                .padding(.horizontal)

                // Event Description Box
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.white.opacity(0.1))
                    .frame(maxWidth: .infinity)
                    .padding()
                    .overlay(
                        Text(event.description.isEmpty ? "No description available." : event.description) // Pull description
                            .foregroundColor(.white)
                            .font(.title3)
                            .padding()
                    )

                Spacer()

                // Buttons at the bottom
                HStack(spacing: 40) {
                    Button(action: { isRSVPd.toggle() }) {
                        Image(systemName: isRSVPd ? "checkmark.circle.fill" : "checkmark.circle")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .foregroundColor(barBackgroundColor)
                    }

                    Button(action: { isInterested.toggle() }) {
                        Image(systemName: isInterested ? "heart.fill" : "heart")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .foregroundColor(barBackgroundColor)
                    }

                    Button(action: { isShareSheetShowing = true }) {
                        Image(systemName: "square.and.arrow.up")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .foregroundColor(barBackgroundColor)
                    }
                    .sheet(isPresented: $isShareSheetShowing) {
                        ShareSheet(activityItems: ["Check out this event: \(event.name) on \(event.date) at \(event.location)"])
                    }

                    Button(action: {
                        if let url = URL(string: "https://www.example.com/report-event") {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Image(systemName: "exclamationmark.triangle")
                            .resizable()
                            .frame(width: 40, height: 40)
                            .foregroundColor(barBackgroundColor)
                    }
                }
                .frame(maxWidth: .infinity)
                .padding(.horizontal)
                .padding(.bottom, 20)
            }
        }
    }
}


#Preview {
    ContentView()
}
