import SwiftUI
import FirebaseFirestore

struct OnCampusView: View {
    @State private var events: [Event] = []
    @State private var sortMethod: SortMethod = .date
    @State private var sortAscending = true

    let barBackgroundColor = Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1)) // Hex color #fcb716
    let appBackgroundColor = Color(UIColor(red: 0/255, green: 56/255, blue: 101/255, alpha: 1)) // Hex color #003865

    init() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(red: 0/255, green: 56/255, blue: 101/255, alpha: 1)
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
    }

    enum SortMethod: String, CaseIterable, Identifiable {
        case date = "Date"
        case alphabetically = "Alphabetically"
        case interested = "People Interested"

        var id: String { self.rawValue }
    }

    var body: some View {
        VStack {
            ScrollViewReader { scrollView in
                List(events) { event in
                    NavigationLink(destination: EventDetailView(event: event)) {
                        HStack {
                            VStack(alignment: .leading) {
                                Text(event.name)
                                    .font(.title2)
                                    .bold()
                                    .foregroundColor(.white)
                                Text(event.date.formatted(date: .abbreviated, time: .shortened))
                                    .font(.headline)
                                    .foregroundColor(.white)
                                Divider()
                                    .background(Color.white)
                            }
                            Spacer()
                            VStack(alignment: .trailing) {
                                Text("\(event.interestedPeople) Interested")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                if event.rsvpStatus == "RSVP'd" {
                                    Text(event.rsvpStatus)
                                        .font(.headline)
                                        .foregroundColor(barBackgroundColor)
                                }
                            }
                        }
                        .padding()
                    }
                    .listRowBackground(appBackgroundColor)
                }
                .listStyle(PlainListStyle())
            }
        }
        .background(appBackgroundColor.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("On Campus")
                    .foregroundColor(.white)
                    .font(.system(size: 22, weight: .bold))
            }

            ToolbarItem(placement: .navigationBarTrailing) {
                ZStack {
                    Capsule()
                        .fill(barBackgroundColor)
                        .frame(height: 40)
                    Menu {
                        Button(action: { handleSort(.date) }) {
                            Label("Date", systemImage: "calendar")
                        }
                        Button(action: { handleSort(.alphabetically) }) {
                            Label("Alphabetically", systemImage: "textformat")
                        }
                        Button(action: { handleSort(.interested) }) {
                            Label("People Interested", systemImage: "person.3")
                        }
                    } label: {
                        HStack {
                            Text("Sort")
                                .foregroundColor(.black)
                            Image(systemName: "arrow.up.arrow.down")
                                .foregroundColor(.black)
                        }
                        .padding(.horizontal, 2)
                        .frame(height: 40)
                    }
                }
            }
        }
        .onAppear {
            fetchEvents(isOffCampus: false) { fetchedEvents in
                self.events = fetchedEvents
            }
        }
    }

    private func handleSort(_ method: SortMethod) {
        if sortMethod == method {
            sortAscending.toggle()
        } else {
            sortMethod = method
            sortAscending = true
        }
        sortEvents()
    }

    private func sortEvents() {
        switch sortMethod {
        case .date:
            events.sort { sortAscending ? $0.date < $1.date : $0.date > $1.date }
        case .alphabetically:
            events.sort { sortAscending ? $0.name < $1.name : $0.name > $1.name }
        case .interested:
            events.sort { sortAscending ? $0.interestedPeople < $1.interestedPeople : $1.interestedPeople < $0.interestedPeople }
        }
    }

    private func fetchEvents(isOffCampus: Bool, completion: @escaping ([Event]) -> Void) {
        let db = Firestore.firestore()
        db.collection("Events")
            .whereField("isOffCampus", isEqualTo: isOffCampus)
            .order(by: "date")
            .getDocuments { snapshot, error in
                if let error = error {
                    print("Error fetching events: \(error.localizedDescription)")
                    completion([])
                    return
                }

                let fetchedEvents = snapshot?.documents.compactMap { doc -> Event? in
                    let data = doc.data()
                    return Event(
                        id: doc.documentID,
                        date: (data["date"] as? Timestamp)?.dateValue() ?? Date(),
                        name: data["name"] as? String ?? "",
                        location: data["location"] as? String ?? "",
                        interestedPeople: data["interestedPeople"] as? Int ?? 0,
                        rsvpStatus: data["rsvpStatus"] as? String ?? "",
                        host: data["host"] as? String ?? "",
                        description: data["description"] as? String ?? ""
                    )
                } ?? []
                completion(fetchedEvents)
            }
    }
}
#Preview {
    ContentView()
}
