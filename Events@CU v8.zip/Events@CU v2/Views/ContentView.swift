import SwiftUI

struct ContentView: View {
    // Constants for reused colors
    let barBackgroundColor = Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1)) // Hex color #fcb716
    let appBackgroundColor = Color(UIColor(red: 0/255, green: 56/255, blue: 101/255, alpha: 1)) // Hex color #003865
    
    // State variable to control the drawer menu visibility
    @State private var isDrawerOpen = false
    
    var body: some View {
        NavigationView {
            ZStack {
                appBackgroundColor.ignoresSafeArea() // Set background color to #003865
                
                VStack {
                    topBar() // Add the top bar at the top of the screen
                    
                    Spacer()
                    
                    // Welcome message with multi-line text structure
                    VStack(spacing: 10) {
                        Text("Welcome to")
                            .font(.system(size: 36))
                            .foregroundColor(.white)
                            .bold()
                        
                        Text("Events@CU")
                            .font(.system(size: 48))
                            .foregroundColor(.white)
                            .bold()
                        
                        Text("-----")
                            .font(.system(size: 36))
                            .foregroundColor(.white)
                            .bold()
                    }
                    
                    Spacer()
                }
            }
            .safeAreaInset(edge: .bottom) {
                bottomBar()
            }
            .navigationTitle("")
            .overlay(
                // Overlay the drawer menu on top of the main content
                DrawerMenuView(isOpen: $isDrawerOpen, backgroundColor: appBackgroundColor, titleColor: barBackgroundColor)
            )
        }
    }
    
    // MARK: - Top Bar with Hamburger and Account Icons
    @ViewBuilder
    private func topBar() -> some View {
        ZStack {
            barBackgroundColor // Set background color to hex #fcb716
                .ignoresSafeArea(edges: .top)
            
            HStack {
                // Hamburger Menu Icon
                Button(action: {
                    withAnimation(.easeInOut(duration: 0.2)) { // Set shorter animation duration
                        isDrawerOpen.toggle() // Toggle the drawer menu visibility
                    }
                }) {
                    Image("hamburger")
                        .resizable()
                        .frame(width: 48, height: 48)
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                // Account Icon
                NavigationLink(destination: ProfileView()) {
                    Image(systemName: "person.crop.circle")
                        .resizable()
                        .frame(width: 36, height: 36)
                        .foregroundColor(.black)
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 10)
        }
    }
    
    // MARK: - Bottom Bar with Larger Icons and Text
    @ViewBuilder
    private func bottomBar() -> some View {
        ZStack {
            barBackgroundColor // Set background color to hex #fcb716
                .ignoresSafeArea(edges: .bottom)
                .padding(.vertical, 200)
            
            HStack {
                Spacer()
                
                // On Campus Events Button
                VStack(spacing: 5) {
                    NavigationLink(destination: EventListView()) {
                        Image("bwschool")
                            .resizable()
                            .frame(width: 60, height: 60)
                    }
                    Text("On Campus")
                        .foregroundColor(.black)
                        .font(.system(size: 20))
                        .bold()
                }
                
                Spacer(minLength: 90)
                
                // Off Campus Events Button
                VStack(spacing: 5) {
                    NavigationLink(destination: OffCampusEventListView()) {
                        Image("bwcar")
                            .resizable()
                            .frame(width: 60, height: 60)
                    }
                    Text("Off Campus")
                        .foregroundColor(.black)
                        .font(.system(size: 20))
                        .bold()
                }
                
                Spacer()
            }
            .padding(.vertical, 20) // Adjust this padding to increase or decrease height
        }
    }
}

#Preview {
    ContentView()
}
