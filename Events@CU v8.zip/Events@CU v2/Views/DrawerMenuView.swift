//
//  DrawerMenuView.swift
//  Events@CU
//
//  Created by Jesse Mitra on 11/15/24.
//

import SwiftUI

struct DrawerMenuView: View {
    @Binding var isOpen: Bool
    let backgroundColor: Color
    let titleColor: Color
    
    // Adjustable space height
    let spaceHeight: CGFloat = 100 // Adjust this value to control space between "More" and buttons
    
    var body: some View {
        ZStack(alignment: .leading) {
            if isOpen {
                // Semi-transparent background to dim the main content
                Color.black.opacity(0.15)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.easeInOut(duration: 0.2)) { // Set shorter animation duration for closing
                            isOpen.toggle()
                        }
                    }
                
                // Drawer menu content
                VStack(alignment: .leading) {
                    // "More" title at the top
                    Text("More")
                        .font(.system(size: 32))
                        .bold()
                        .foregroundColor(titleColor)
                        .padding(.top, 20)
                    
                    Spacer()
                        .frame(height: spaceHeight)
                    
                    // NavigationLinks to separate views
                    VStack(alignment: .leading, spacing: 30) {
                        NavigationLink(destination: EventAdditionView()) {
                            Text("Add an Event")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                        
                        NavigationLink(destination: MyEventsView()) {
                            Text("My Events")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                        
                        NavigationLink(destination: RewardsView()) {
                            Text("Rewards")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                        
                        NavigationLink(destination: NotificationSettingsView()) {
                            Text("Notifications")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                        
                        NavigationLink(destination: ContactUsView()) {
                            Text("Contact Us")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                        
                        NavigationLink(destination: AboutUsView()) {
                            Text("About")
                                .font(.headline)
                                .bold()
                                .foregroundColor(.white)
                        }
                    }
                    
                    Spacer()
                }
                .padding()
                .background(backgroundColor)
                .transition(.move(edge: .leading))
            }
        }
    }
}

#Preview {
    ContentView()
}
