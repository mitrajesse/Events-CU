import SwiftUI
import FirebaseAuth


struct ProfileView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var isLoggedIn = Auth.auth().currentUser != nil
    @State private var showAlert = false
    @State private var alertMessage = ""

    var body: some View {
        ZStack {
            Color(UIColor(red: 0/255, green: 56/255, blue: 101/255, alpha: 1)) // Hex #003865
                .ignoresSafeArea()

            VStack(spacing: 20) {
                Text("Profile")
                    .font(.largeTitle)
                    .bold()
                    .foregroundColor(Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1))) // Hex #fcb716
                    .padding()

                if isLoggedIn {
                    // Logged-in user display
                    Text("Welcome, \(Auth.auth().currentUser?.email ?? "User")!")
                        .foregroundColor(.white)

                    Button(action: signOut) {
                        Text("Sign Out")
                            .bold()
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1)))
                            .foregroundColor(.black)
                            .cornerRadius(10)
                    }
                } else {
                    // Login form
                    VStack(spacing: 15) {
                        TextField("Email", text: $email)
                            .textInputAutocapitalization(.none)
                            .autocorrectionDisabled(true)
                            .keyboardType(.emailAddress)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(8)

                        SecureField("Password", text: $password)
                            .textInputAutocapitalization(.none)
                            .autocorrectionDisabled(true)
                            .textContentType(.password) // Explicitly indicate this is a password field
                            .padding()
                            .background(Color.white)
                            .cornerRadius(8)

                        Button(action: login) {
                            Text("Log In")
                                .bold()
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1)))
                                .foregroundColor(.black)
                                .cornerRadius(10)
                        }

                        Button(action: createAccount) {
                            Text("Create Account")
                                .bold()
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1)))
                                .foregroundColor(.black)
                                .cornerRadius(10)
                        }
                    }
                }

                Spacer()
            }
            .padding()
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Authentication"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }

    // MARK: - Firebase Authentication Functions

    private func login() {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                alertMessage = "Login failed: \(error.localizedDescription)"
                showAlert = true
            } else {
                isLoggedIn = true
            }
        }
    }

    private func createAccount() {
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                alertMessage = "Account creation failed: \(error.localizedDescription)"
                showAlert = true
            } else {
                alertMessage = "Account created successfully!"
                showAlert = true
                isLoggedIn = true
            }
        }
    }

    private func signOut() {
        do {
            try Auth.auth().signOut()
            isLoggedIn = false
        } catch {
            alertMessage = "Sign-out failed: \(error.localizedDescription)"
            showAlert = true
        }
    }
}
#Preview {
    ContentView()
}
