import SwiftUI

struct ContentView: View {
    // Constants for reused colors
    let barBackgroundColor = Color(UIColor(red: 252/255, green: 183/255, blue: 22/255, alpha: 1)) // #fcb716
    let appBackgroundColor = Color(UIColor(red: 0/255, green: 56/255, blue: 101/255, alpha: 1)) // #003865
    
    @StateObject private var userViewModel = UserViewModel()
    @State private var isDrawerOpen = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                appBackgroundColor.ignoresSafeArea()
                
                VStack {
                    Spacer()
                    
                    // Welcome Text
                    Text("Welcome to")
                        .font(.system(size: 36))
                        .foregroundColor(.white)
                        .bold()
                    
                    Text("Events@CU")
                        .font(.system(size: 48))
                        .foregroundColor(.white)
                        .bold()
                    
                    Text(userViewModel.userName)
                        .font(.system(size: 36))
                        .foregroundColor(.white)
                        .bold()
                    
                    Spacer()
                    
                    // Navigation Buttons in HStack
                    HStack(spacing: -30) {
                        NavigationLink(destination: OnCampusView()) {
                            buttonView(iconName: "bwschool", titleTop: "On", titleBottom: "Campus", iconWidth: 80, iconHeight: 80, spacing: 10)
                        }
                        
                        NavigationLink(destination: OffCampusView()) {
                            buttonView(iconName: "bwcar", titleTop: "Off", titleBottom: "Campus", iconWidth: 100, iconHeight: 100, spacing: -10)

                        }
                    }
                    .padding(.bottom, 40)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            isDrawerOpen.toggle()
                        }
                    } label: {
                        Image("hamburger")
                            .resizable()
                            .frame(width: 48, height: 48)
                            .offset(y: -4)
                    }
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink(destination: ProfileView()) {
                        Image(systemName: "person.crop.circle")
                            .resizable()
                            .frame(width: 36, height: 36)
                            .foregroundColor(.black)
                            .offset(y: -4)
                    }
                }
            }
            .toolbarBackground(barBackgroundColor, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
        .overlay(
            DrawerMenuView(isOpen: $isDrawerOpen, backgroundColor: appBackgroundColor, titleColor: barBackgroundColor)
        )
    }
    
    // Custom button view with two-line text and icon
    private func buttonView(iconName: String, titleTop: String, titleBottom: String, iconWidth: CGFloat, iconHeight: CGFloat, spacing: CGFloat) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12)
                .fill(barBackgroundColor)
                .frame(height: 150) // Increased height for better alignment
                .frame(maxWidth: .infinity)

            VStack(spacing: spacing) { // Use VStack for text alignment
                Image(iconName) // Custom icon name
                    .resizable()
                    .scaledToFit()
                    .frame(width: iconWidth, height: iconHeight)

                Text("\(titleTop) \(titleBottom)") // Combine text into a single line
                    .font(.title2) // Adjusted font size
                    .bold()
                    .foregroundColor(.black)
            }
            .padding()
        }
        .padding(.horizontal, 30) // Outer padding for spacing
    }
}

#Preview {
    ContentView()
}
